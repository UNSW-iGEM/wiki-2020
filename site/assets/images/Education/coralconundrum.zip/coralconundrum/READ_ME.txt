Hello fellow traveler!
Welcome to Coral Conundrum, the UNSW iGEM Virtual Escape Room.
You are a Coral-being from the region of the Green-Blue Reef (GBR). 
You are a scientist who specialises in the infrastructure of the Coral 
which homes and shelters your friends and family, 
however not everyone out there wants your town to be there anymore...


---
Non-puzzle statement: This project heavily parallels an exaggerated version 
of the journey the UNSW iGEM team has taken! Although you do not need 
any wet lab knowledge to do the puzzles, the story outlines saving the coral 
reef through bio engineering the coral to be heat resistant (in this case, 
EXTREMELY HEAT RESISTANT).

Every excel file has the puzzle and some hints attached. I recommend doing
the escape room with a group of your friends, family or even co-workers!
I also recommend really trying the puzzles until you REALLY need the hints.
There will also be a solution detailing the path to getting the answer.

If you do not have excel, I can perhaps recommend moving it to Google Drive
then using Google Sheets from there. Using Google Forms and Google Sheets was
the initial way of doing the escape room so feel free to email us at unswigem2020@gmail.com
to receive that link!
