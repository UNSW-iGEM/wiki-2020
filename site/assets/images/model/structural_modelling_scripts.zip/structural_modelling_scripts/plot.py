#!/usr/bin/env python3
import numpy as np

# these two lines are necessary for gadi
# this sets the backend so that an interactive GUI is not launched
# when plotting the graphs
import matplotlib
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import sys
import os

# define the filename to parse for data and the output .png filename
filename = "clean_" + sys.argv[1]
pngfilename = sys.argv[1][:-4] + ".png"

# define the x-axis label, y-axis label and title
# and remove the double quotes around it
xlabel = sys.argv[2][1:-1]
ylabel = sys.argv[3][1:-1]
title = sys.argv[4][1:-1]

# swap the underscores in any labels for white space
xlabel = xlabel.replace("_", " ")
ylabel = ylabel.replace("_", " ")
title = title.replace("_", " ")

fig, ax = plt.subplots()

# convert the data from the .xvg file to a numpy array, turning columns to list items
a = np.genfromtxt(filename,unpack=True)

# if there is a legend argument, define the legend argument, swap underscores
# and plot the graph with a legend
if (len(sys.argv)==6):
	legend = sys.argv[5][1:-1]
	legend = legend.replace("_", " ")
	ax.plot(a[0],a[1], label=legend)
	plt.legend()
# otherwise plot the graph without a legend
else:
	ax.plot(a[0],a[1])

# add the x-axis label, y-axis label and title
plt.xlabel(xlabel)
plt.ylabel(ylabel)
plt.title(title)


# use scientific notation for the y axis
plt.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2e'))

# save an output.png file
plt.savefig(pngfilename, pad_inches=0.1)
