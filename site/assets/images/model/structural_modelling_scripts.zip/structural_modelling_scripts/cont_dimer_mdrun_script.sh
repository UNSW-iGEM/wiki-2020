#!/bin/bash

#PBS -P project_name
#PBS -q queue
#PBS -l ngpus=3
#PBS -l ncpus=36
#PBS -l mem=24gb
#PBS -l wd
#PBS -lstorage=scratch/pg25
#PBS -l walltime=12:00:00
#PBS -M email
#PBS -m abe
#PBS -j oe

# start in the wd of the mdp files
# qsub cont_dimer_mdrun_script.sh
set -e						# if any error occurs, exit 1

#INPUT
ntmpi=4 
ompthreads=9
runtime=11

export OMP_NUM_THREADS=$ompthreads
export GMX_DISABLE_GPU_TIMING=TRUE

plot=path_to_plot_script
date=2020_10_26
input=prev_simulation_path
output=curr_simulation_path
analysis_folder=path_to_move_analysis_to
sysname=dimer
start_gro=path_to_first_frame_of_simulation/${sysname}_npt_nW.gro
module load gromacs



# MD production run

gmx mdrun -ntomp $ompthreads -ntmpi $ntmpi -deffnm $sysname'_MD' -gputasks 0001 -nb gpu -pme gpu -npme 1 -v -maxh ${runtime} -cpi $sysname'_MD.cpt' -append -nsteps -1


# # centre and align trajectory - create .gro and .xtc files
# # create a no water version for vmd, _npt becuase the last frame of npt is the first frame of the mdrun
# # printf '1' | gmx trjconv -s $sysname'_npt.tpr' -f $sysname'_npt.gro' -o $sysname'_npt_nW.gro'

# # printf '1' | gmx trjconv -s $sysname'_MD.tpr' -f $sysname'_MD''.gro' -o $sysname'_MD_nW.gro'

# ############
# ## nojump ##
# ############
# # used md5sum and turns out that -ur compact makes no difference

# # # tried -pbc nojump -centre
# # printf '1\n1' | gmx trjconv -s $sysname'_MD.tpr' -f $sysname'_MD.xtc' -o $sysname'_MD_cent_nW_nojump.xtc' -pbc nojump -center
# # # tried -pbc nojump -center -ur compact
# # printf '1\n1' | gmx trjconv -s $sysname'_MD.tpr' -f $sysname'_MD.xtc' -o $sysname'_MD_cent_nW_nojump_compact.xtc' -pbc nojump -center -ur compact

# # ###############
# # ## rot_trans ##
# # ###############

# # # keeps the protein in the center of the box, removes waters
# # # next step requires centred .xtc to not have any waters
# # printf '1\n1' | gmx trjconv -s $sysname'_MD.tpr' -f $sysname'_MD.xtc' -o $sysname'_MD_cent_nW.xtc' -pbc mol -ur compact -center
# # # input protein for centering
# # # output protein

# # # generate fitted trajectory without waters
# # printf '3\n0' | gmx trjconv -s $start_gro -f $sysname'_MD_cent_nW.xtc' -fit rot+trans -o $sysname'_MD_cent_nW_fit.xtc'
# # # align to carbon alphas
# # # ouput everything (waters already removed)

# ###########################
# ## Brian's Special Sauce ##
# ###########################
printf '1' | gmx trjconv -s dimer_MD.tpr -f dimer_MD.xtc -o dimer_MD_whole.xtc -pbc whole

# 2. add nojump to whole trajectory
# inputs are dimer npt nW.gro and MD whole from step 1
printf '1' | gmx trjconv -s ${start_gro} -f dimer_MD_whole.xtc -o dimer_MD_whole_nojump.xtc -pbc nojump

# 3. center the trajectory and fit with rot+trans
# inputs are dimer npt nW.gro and MD whole nojump from step 2
printf '1\n1\n1' | gmx trjconv -s ${start_gro} -f dimer_MD_whole_nojump.xtc -o dimer_MD_whole_nojump_cent_fit.xtc -center -fit rot+trans


##### Analysis ######

module load python3

plot () {
	# define the file to parse
	filename=$1
	base=$(basename $filename .xvg)
	# search the file for the line containing the identifying substring
	# remove the beginning substring, leaving behind the title in double quotes
	# swap all white space for underscores
	xaxis=$(grep "@    xaxis  label " $filename | sed 's/\@    xaxis  label //g' | sed -e 's/ /_/g')
	yaxis=$(grep "@    yaxis  label " $filename | sed 's/\@    yaxis  label //g' | sed -e 's/ /_/g')
	title=$(grep "@    title " $filename | sed 's/\@    title //g' | sed -e 's/ /_/g')
	legend=$(grep "@ s0 legend " $filename | sed 's/\@ s0 legend //g' | sed -e 's/ /_/g')

	# generate a .xvg file without any comments
	grep -v "#\|@" $filename > "clean_"$filename
	echo $filename $xaxis $yaxis $title $legend

	# generate a .csv file so you can plot it using any software
	# grep -v "#\|@" $base".xvg" | sed "s/\t/,/g" > $base".csv"

	# call plot.py to plot the graph
	python3 ${plot} $filename $xaxis $yaxis $title $legend
}


# Create pdb from frame of MD
# printf '1' | gmx trjconv -f dimer_MD_whole_nojump_cent_fit.xtc -s $sysname'_MD.tpr' -o $sysname'_last_frame.pdb' -dump 239280 
# printf '1' | gmx trjconv -f dimer_MD_whole_nojump_cent_fit.xtc -s $sysname'_MD.tpr' -o $sysname'_first_frame.gro' -dump 0 


# # Generate index to ignore the loose C-termini from solvated .gro
# printf 'r 1-211\nq' | gmx make_ndx -f ${start_gro} -o $sysname_1'.ndx'



# RMSD
printf '1\n1' | gmx rms -s $sysname'_first_frame.gro' -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_RMSD_whole_nojump_cent_fit.xvg' 
printf '10\n10' | gmx rms -s $sysname'_first_frame.gro' -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_RMSD_core_nojump_cent_fit.xvg' -n $sysname'.ndx'
printf '4\n4' | gmx rms -s $sysname'_first_frame.gro' -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_RMSD_backbone_nojump_cent_fit.xvg' 
plot $sysname'_RMSD_core_nojump_cent_fit.xvg'
plot $sysname'_RMSD_backbone_nojump_cent_fit.xvg'
plot $sysname'_RMSD_whole_nojump_cent_fit.xvg'

# Radius of gyration
printf '4' | gmx gyrate -s $sysname'_first_frame.gro'  -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_gyrate_backbone_nojump_cent_fit.xvg'
printf '10' | gmx gyrate -s $sysname'_first_frame.gro'  -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_gyrate_core_nojump_cent_fit.xvg' -n $sysname'.ndx'
printf '1' | gmx gyrate -s $sysname'_first_frame.gro'  -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_gyrate_whole_nojump_cent_fit.xvg'

plot $sysname'_gyrate_backbone_nojump_cent_fit.xvg'
plot $sysname'_gyrate_core_nojump_cent_fit.xvg'
plot $sysname'_gyrate_whole_nojump_cent_fit.xvg'

# backbone of core
printf '10\n10' | gmx rms -s $sysname'_first_frame.gro' -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_RMSD_ba_core_nojump_cent_fit.xvg' -n $sysname'_1.ndx'
printf '10' | gmx gyrate -s $sysname'_first_frame.gro'  -f $sysname'_MD_whole_nojump_cent_fit.xtc' -o $sysname'_gyrate_ba_core_nojump_cent_fit.xvg' -n $sysname'_1.ndx'

plot $sysname'_RMSD_ba_core_nojump_cent_fit.xvg'
plot $sysname'_gyrate_ba_core_nojump_cent_fit.xvg'


if ! [[ -d ${analysis_folder} ]]; then mkdir -p ${analysis_folder}/; fi
mv *.xvg ${analysis_folder}
mv *.png ${analysis_folder}


