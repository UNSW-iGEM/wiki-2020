#!/bin/bash

#PBS -P project_name
#PBS -q queue
#PBS -l ngpus=3
#PBS -l ncpus=36
#PBS -l mem=24gb
#PBS -l wd
#PBS -lstorage=scratch/pg25
#PBS -l walltime=12:00:00
#PBS -M email
#PBS -m abe
#PBS -j oe

##############################################################################
#
# This is a sample run script for GROMACS version 2020.1 by Brian Ee with
# some simple analysis steps. The run is modelled off Justin Lemkul's tutorial
# of Lysozyme in Water (http://www.mdtutorials.com/gmx/lysozyme/index.html)
# to be run on NCI Australia's HPC cluster Gadi using the gpuvolta queue.
#
# This script runs a 10 ns simulation on an input file 'CA_pent.pdb' using the
# charmm36-mar2019 force field in a cubic box solvated with the TIP3P water
# model at neutral salt concentration + 150 mM sodium and chloride ions. It
# equilibrates the system with energy minimisation, NVT and NPT equilibration.
# The final simulation can be viewed/analysed with programs such as VMD. I
# generally make my final figures with VMD/ffmpeg/Adobe Premiere Pro (for
# images and videos) or Python/MATLAB/Bash for analysis.
#
# Input parameters (#INPUT), PBS lines (above), .mdp files and printf commands
# will almost certainly need to be adjusted for the system that you are
# simulating. You will probably need to adjust other lines too depending on the
# simulation conditions that you would like to use.
#
##############################################################################

#INPUT
ntmpi=4
ompthreads=6
pdbname=CA_pent
sysname=CA_pent

export OMP_NUM_THREADS=$ompthreads
export GMX_DISABLE_GPU_TIMING=TRUE
module load gromacs

# do this line interactively in the console, as it can be complicated depending on force field/N and C terminii/protonation of side chains
# gmx pdb2gmx -f $pdbname'.pdb' -o $sysname'.gro' -water tip3p -ff charmm36-mar2019 -p $sysname'.top' -ter -ignh

# define the box dimensions with the editconf module
gmx editconf -f $sysname'.gro' -o $sysname'_newbox.gro' -c -d 1.0 -bt cubic

# add water molecules to the box
gmx solvate -cp $sysname'_newbox.gro' -cs spc216.gro -o $sysname'_solv.gro' -p $sysname'.top'

# add ions
gmx grompp -f ions.mdp -c $sysname'_solv.gro' -p $sysname'.top' -o ions.tpr

printf '13' | gmx genion -s ions.tpr -o $sysname'_solv_ions.gro' -p $sysname'.top' -pname NA -nname CL -neutral

# energy minimisation
gmx grompp -f minim.mdp -c $sysname'_solv_ions.gro' -p $sysname'.top' -o $sysname'_em.tpr'

gmx mdrun -ntomp $ompthreads -ntmpi $ntmpi -deffnm $sysname'_em' -dlb no -notunepme

# NVT equilibration
gmx grompp -f nvt.mdp -c $sysname'_em.gro' -r $sysname'_em.gro' -p $sysname'.top' -o $sysname'_nvt.tpr'

gmx mdrun -ntomp $ompthreads -ntmpi $ntmpi -deffnm $sysname'_nvt' -dlb no -notunepme -gputasks 0001 -nb gpu -pme gpu -npme 1 -v

# NPT equilibration
gmx grompp -f npt.mdp -c $sysname'_nvt.gro' -r $sysname'_nvt.gro' -t $sysname'_nvt.cpt' -p $sysname'.top' -o $sysname'_npt.tpr'

gmx mdrun -ntomp $ompthreads -ntmpi $ntmpi -deffnm $sysname'_npt' -dlb no -notunepme -gputasks 0001 -nb gpu -pme gpu -npme 1 -v

# MD production run
gmx grompp -f md.mdp -c $sysname'_npt.gro' -t $sysname'_npt.cpt' -p $sysname'.top' -o $sysname'_MD.tpr'

gmx mdrun -ntomp $ompthreads -ntmpi $ntmpi -deffnm $sysname'_MD' -gputasks 0001 -nb gpu -pme gpu -npme 1 -v

# centre and align trajectory - create .gro and .xtc files
# load this into vmd
printf '1' | gmx trjconv -s $sysname'_npt.tpr' -f $sysname'_npt.gro' -o $sysname'_npt_nW.gro'

printf '1\n1' | gmx trjconv -s $sysname'_MD.tpr' -f $sysname'_MD.xtc' -o $sysname'_MD_cent_nW.xtc' -pbc mol -ur compact -center


##### Analysis ######

module load python3

plot () {
	# define the file to parse
	filename=$1
	# search the file for the line containing the identifying substring
	# remove the beginning substring, leaving behind the title in double quotes
	# swap all white space for underscores
	xaxis=$(grep "@    xaxis  label " $filename | sed 's/\@    xaxis  label //g' | sed -e 's/ /_/g')
	yaxis=$(grep "@    yaxis  label " $filename | sed 's/\@    yaxis  label //g' | sed -e 's/ /_/g')
	title=$(grep "@    title " $filename | sed 's/\@    title //g' | sed -e 's/ /_/g')
	legend=$(grep "@ s0 legend " $filename | sed 's/\@ s0 legend //g' | sed -e 's/ /_/g')

	#generate a .xvg file without any comments
	grep -v "#\|@" $filename > "clean_"$filename
	echo $filename $xaxis $yaxis $title $legend
	# call plot.py to plot the graph
	python3 plot.py $filename $xaxis $yaxis $title $legend
}

# Energy minimisation analysis:
printf '10' | gmx energy -f $sysname'_em.edr' -o $sysname'_potential.xvg'

plot $sysname'_potential.xvg'

# Analyse the temperature progression after NVT
printf '16' | gmx energy -f $sysname'_nvt.edr' -o $sysname'_temperature.xvg'

plot $sysname'_temperature.xvg'

# Analyse the pressure progression after NPT
printf '18' | gmx energy -f $sysname'_npt.edr' -o $sysname'_pressure.xvg'

plot $sysname'_pressure.xvg'

# Analyse the density progression after NPT
printf '24' | gmx energy -f $sysname'_npt.edr' -o $sysname'_density.xvg'

plot $sysname'_density.xvg'

# Radius of gyration
printf '1' | gmx gyrate -s $sysname'_npt_nW.gro' -f $sysname'_MD_cent_nW.xtc' -o $sysname'_gyrate.xvg'

plot $sysname'_gyrate.xvg'

mkdir analysis
mv *.xvg analysis
mv *.png analysis
cd analysis
mkdir png
mv *.png png
