model definition don't have assignments, but variables are automatically created for every component.
